/**
 * Generic GUI components for input dialogs.
 */
package org.opentcs.virtualvehicle.inputcomponents;
