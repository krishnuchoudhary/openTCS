/**
 * Components supporting extension and customization of the openTCS kernel control center
 * application.
 */
package org.opentcs.customizations.controlcenter;
