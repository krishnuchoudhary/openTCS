/**
 * Components supporting extension and customization of the openTCS plant overview application.
 */
package org.opentcs.customizations.plantoverview;
